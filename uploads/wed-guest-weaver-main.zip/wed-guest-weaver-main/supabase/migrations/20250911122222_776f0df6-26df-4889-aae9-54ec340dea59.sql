-- Enable RLS on tables that have policies but RLS disabled
ALTER TABLE public.invitati ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;